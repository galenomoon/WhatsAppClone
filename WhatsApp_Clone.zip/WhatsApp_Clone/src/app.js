import { WhatsAppController } from './controller/WhatsAppController'

window.app = new WhatsAppController();