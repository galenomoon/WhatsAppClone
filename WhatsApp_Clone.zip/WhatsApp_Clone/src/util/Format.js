class Format {

    static getCamelCase(text) {
        let div = document.createElement('div');

        div.innerHTML = `<div data-${text}="id"></div>`;

        //OBJECT.KEYS (NATIVO DO JS)| Traz um ARRAY com todas as chaves de um determinado objeto
        return Object.keys(div.firstChild.dataset)[0];

    }
}



//======================== LÓGICA POR TRAZ DO getCamelCase(text) ===========================
/*o Dataset vem automaticamente em CamelCase, mas para usarmos ele é preciso que ele esteja ligado
 a um elemento HTML, elemento este que não precisa ser renderizado na tela então será criado uma 
 <div> para gerar o dataset, e então o resgatar desse elemento HTML gerado de volta para o JS */