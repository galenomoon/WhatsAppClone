//========================================= WHATSAPP CLONE - CONTROLLER =========================================

class WhatsAppController {

    constructor() {

        this.loadElements(); //Carregando Elementos
    }

    loadElements() {

        this.el = {}; //Criando um objeto

        // selecione todos os ID's, e para cada elemento ID selecionado:
        document.querySelectorAll('[id]').forEach(element => {

            //Crie um objeto, e o formate em Camel Case. Este é um elemento.
            this.el[Format.getCamelCase(element.id)] = element;

        })
    }
}