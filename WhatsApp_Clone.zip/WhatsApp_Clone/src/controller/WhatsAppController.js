//========================================= WHATSAPP CLONE - CONTROLLER =========================================

class WhatsAppController {

    constructor() {

        this.elementsPrototype(); //Tornando a propramação mais prática
        this.loadElements(); //Carregando Elementos
        this.initEvents(); //Inicializando Eventos

    }


    //==================== INICIALIZANDO EVENTOS ====================
    initEvents() {

        // ========== ABRE O PAINEL DE EDITAR PERFIL 
        this.el.myPhoto.on('click', e => {
            this.closeAllLeftPanel();
            this.el.panelEditProfile.show();
            setTimeout(() => { this.el.panelEditProfile.addClass('open'); }, 300) // Sincronizado com o tempo de animação CSS
        })

        // ========== FECHA O PAINEL EDITAR PERFIL 
        this.el.btnClosePanelEditProfile.on('click', e => {
            this.el.panelEditProfile.removeClass('open');
        })

        // ========== ABRE O PAINEL DE ADICIONAR UM CONTATO 
        this.el.btnNewContact.on('click', e => {
            this.closeAllLeftPanel();
            this.el.panelAddContact.show();
            setTimeout(() => { this.el.panelAddContact.addClass('open'); }, 300) // Tempo de Animação do CSS
        })

        // ========== FECHA O PAINEL DE ADICIONAR UM CONTATO 
        this.el.btnClosePanelAddContact.on('click', e => {
            this.el.panelAddContact.removeClass('open');
        })

        // ========== EDITAR FOTO 
        this.el.photoContainerEditProfile.on('click', e => {
            this.el.inputProfilePhoto.click()
        })

        // ========== EDITAR NOME DE USUÁRIO
        this.el.inputNamePanelEditProfile.on('keypress', e => {
            if (e.key == "Enter") {
                e.preventDefault();
                this.el.btnSavePanelEditProfile.click();
            }
        })

        // ========== SALVA NOME DE USUÁRIO DIGITADO
        this.el.btnSavePanelEditProfile.on('click', e => {
            console.log(this.el.inputNamePanelEditProfile.innerHTML)
        })

        // ========== ENVIA EMAIL A SER ADICIONADO
        this.el.formPanelAddContact.on('submit', e => {
            e.preventDefault();
            let formData = new FormData(this.el.formPanelAddContact);
        })

        // ========== ABRE CONVERSA
        this.el.contactsMessagesList.querySelectorAll('.contact-item').forEach(item => {
            this.el.home.hide();
            item.on('click', e => {
                this.el.main.css({
                    display: 'flex'
                });
            });
        });

        // ========== ABRE O MENU DE INDEXAR ARQUIVOS
        this.el.btnAttach.on('click', e => {

            e.stopPropagation(); //Não aplique este evento às camadas à cima, aos seus ancestrais
            this.el.menuAttach.addClass('open');
            document.addEventListener('click', this.closeMenuAttach.bind(this))
        });

        // ========== BTN PHOTO MENU INDEXAR ARQUIVO
        this.el.btnAttachPhoto.on('click', e => {
            this.el.inputPhoto.click()
        });

        this.el.inputPhoto.on('change', e => { //ABRIR INPUT DE INSERÇÃO DE ARQUIVO

            console.log(this.el.inputPhoto.files);

            [...this.el.inputPhoto.files].forEach(file => {

                console.log(file)
            });
        });

        // ========== BTN CAMERA | MENU INDEXAR ARQUIVO
        this.el.btnAttachCamera.on('click', e => {
            this.closeAllMainPanel();
            this.el.panelCamera.addClass('open')
            this.el.panelCamera.css({
                'height': 'calc(100%)'
            })
        });
        this.el.btnClosePanelCamera.on('click', e => { //FECHAR PAINEL DA CÂMERA
            this.closeAllMainPanel();
            this.el.panelMessagesContainer.show()
        })
        this.el.btnTakePicture.on('click', e => { //BTN TIRAR FOTO
            console.log('*imagine um som de câmera antiga*')
        })

        // ========== BTN CONTATO | MENU INDEXAR ARQUIVO
        this.el.btnAttachContact.on('click', e => {
            this.el.modalContacts.show();
        });

        this.el.btnCloseModalContacts.on('click', e => { //FECHAR ABA DE CONTATOS
            this.el.modalContacts.hide();
        })

        // ========== BTN DOCUMENTO | MENU INDEXAR ARQUIVO
        this.el.btnAttachDocument.on('click', e => {
            this.closeAllMainPanel();
            this.el.panelDocumentPreview.addClass('open')
            this.el.panelDocumentPreview.css({
                'height': 'calc(100%)'
            })
        });

        this.el.btnClosePanelDocumentPreview.on('click', e => { //FECHAR PAINEL DE ENVIO DE DOCUMENTO
            this.closeAllMainPanel();
            this.el.panelMessagesContainer.show()
        })

        this.el.btnSendDocument.on('click', e => { //BTN ENVIAR DOCUMENTO
            console.log('send document')
        })

        //========== MICROFONE | MANDAR AUDIO
        this.el.btnSendMicrophone.on('click', e => {

            this.startRecordMicrophoneTime();
            this.el.recordMicrophone.show();
            this.el.btnSendMicrophone.hide();
        })

        this.el.btnCancelMicrophone.on('click', e => { //CANCELAR ENVIO DE AUDIO

            this.closeRecordMicrophone();
        })

        this.el.btnFinishMicrophone.on('click', e => { //FINALIZAR GRAVAÇÃO

            this.closeRecordMicrophone();
        })

        //========== ENVIAR MENSAGEM

        this.el.inputText.on('keypress', e => { // APERTANDO ENTER NO INPUTTEXT

            if (e.key === 'Enter' && !e.ctrlKey) {

                e.preventDefault();
                this.el.btnSend.click();
            }
        })

        this.el.inputText.on('keyup', e => { // AO DIGITAR UMA MENSAGEM

            if (this.el.inputText.innerHTML.length) {

                this.el.inputPlaceholder.hide()
                this.el.btnSendMicrophone.hide()
                this.el.btnSend.show()
            } else {

                this.el.inputPlaceholder.show()
                this.el.btnSendMicrophone.show()
                this.el.btnSend.hide()
            }
        })
        this.el.btnSend.on('click', e => { // BTN DE ENVIAR MENSAGEM

            console.log(this.el.inputText.innerHTML)
            this.el.inputText.innerHTML = '';
        })

        this.el.btnEmojis.on('click', e => { // ABRIR PAINEL DE EMOJIS

            this.el.panelEmojis.toggleClass('open')
        })

        this.el.panelEmojis.querySelectorAll('.emojik').forEach(emoji => {

            emoji.on('click', e => {

                let img = this.el.imgEmojiDefault.cloneNode() //CLONENODE | Duplica as imagens e suas propriedades

                img.style.cssText = emoji.style.cssText
                img.dataset.unicode = emoji.dataset.unicode //Tornando o código amigável
                img.alt = emoji.dataset.unicode

                emoji.classList.forEach(name => {
                    img.classList.add(name)
                })

                let cursor = window.getSelection()

                if (!cursor.focusNode.id || !cursor.focusNode.id == 'input-text') {
                    this.el.inputText.focus();
                    cursor = window.getSelection()
                }

                let range = document.createRange()

                range = cursor.getRangeAt(0)

                range.deleteContents()

                let frag = document.createDocumentFragment()

                frag.appendChild(img)

                range.insertNode(frag)

                range.setStartAfter(img)

                this.el.inputText.dispatchEvent(new Event('keyup')) //FORÇA UM EVENTO A OCORRER
            })
        })


    }

    //============  FORMATAÇÃO DO TEMPO DE GRAVAÇÃO DE AUDIO
    formatRecordTime(duration) {

        let seconds = parseInt((duration / 1000) % 60);
        let minutes = parseInt(duration / (1000 * 60) % 60);
        let hours = parseInt(duration / (1000 * 60 * 60) % 24);

        if (seconds < 10) {
            seconds = `0${seconds}`
        } else {
            seconds = `${seconds}`
        }

        if (hours > 0) {
            return `${hours}:${minutes}:${seconds}`
        }
        if (minutes > 0) {
            return `${minutes}:${seconds}`
        }
        if (seconds >= 0) {
            return `00:${seconds}`
        }
    }

    //============ INICIO DE GRAVAÇÃO DE AUDIO
    startRecordMicrophoneTime() {

        this.el.recordMicrophoneTimer.innerHTML = "00:00";

        let start = Date.now();

        this._recordMicrophoneInterval = setInterval(() => {

            let time = this.formatRecordTime(Date.now() - start)

            this.el.recordMicrophoneTimer.innerHTML = time

        }, 100)

    }

    //============ FECHAR GRAVAÇÃO DE AUDIO
    closeRecordMicrophone() {

        this.el.recordMicrophone.hide();
        this.el.btnSendMicrophone.show();
        clearInterval(this._recordMicrophoneInterval)

    }

    //============ FECHAR OS PAINEIS PRINCIPAIS
    closeAllMainPanel() {
        this.el.panelMessagesContainer.hide()
        this.el.panelDocumentPreview.removeClass('open')
        this.el.panelCamera.removeClass('open')
    }

    //============ FECHAR O MENU DE ANEXAR
    closeMenuAttach(e) {
        document.removeEventListener('click', this.closeMenuAttach)
        this.el.menuAttach.removeClass('open');
    }

    //==================== FECHA TODOS OS PAINEIS À ESQUERDA ====================
    closeAllLeftPanel() {
        this.el.panelEditProfile.hide();
        this.el.panelAddContact.hide();
    }

    //==================== CARREGANDO ELEMENTOS ID to CAMELCASE ====================

    loadElements() {

        this.el = {}; //Criando um objeto
        // selecione todos os ID's, e para cada elemento ID selecionado:
        document.querySelectorAll('[id]').forEach(element => {
            //Crie um objeto, e o formate em Camel Case. Este é um elemento.
            this.el[Format.getCamelCase(element.id)] = element;

        })
    }

    //==================== PROTOTYPE | CRIANDO FUNÇÕES "NATIVAS" ====================
    elementsPrototype() {

        Element.prototype.hide = function() { //HIDE
            this.style.display = 'none';
            return this;
        }
        Element.prototype.show = function() { //SHOW
            this.style.display = 'block';
            return this;
        }
        Element.prototype.toggle = function() { //TOGGLE | Interruptor
            this.style.display = (this.style.display === 'none') ? "block" : "none";
            return this;
        }
        Element.prototype.on = function(events, fn) { //ON | addEventListener
            events.split(' ').forEach(event => {
                this.addEventListener(event, fn)
            })
            return this;
        }
        Element.prototype.css = function(styles) { //CSS | Atalho que puxa o CSS
            for (let name in styles) {
                this.style[name] = styles[name];
            }
            return this;
        }
        Element.prototype.addClass = function(name) { //ADDCLASS
            this.classList.add(name);
            return this;
        }
        Element.prototype.removeClass = function(name) { //REMOVE
            this.classList.remove(name);
            return this;
        }
        Element.prototype.toggleClass = function(name) { //TOGGLECLASS
            this.classList.toggle(name);
            return this;
        }
        Element.prototype.hasClass = function(name) { //HASCLASS
            return this.classList.contains(name);
        }
        HTMLFormElement.prototype.getForm = function() { //GETFORM | Puxa o formdata
            return new FormData(this)
        }
        HTMLFormElement.prototype.toJSON = function() { //TOJSON 
            let json = {};
            this.getForm().forEach((value, key) => {
                json[key] = value
            })
            return json;
        }
    }
}


// =========================== LÓGICA POR TRAZ DO ElementsPrototype() ===========================        
/*
~ Antes do HTML ser um HTML ele é apenas um Element

==> Element.prototype.[nome da função a ser criada] = function{
    O QUE FARÁ ESTA FUNCTION
}
*/