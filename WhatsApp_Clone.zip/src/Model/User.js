//======== MODEL | MANIPULAÇÃO, CONSULTA, ARMAZENAMENTO, ALTERAÇÃO DOS DADOS =================

import { Firebase } from "./../util/Firebase";
import { ClassEvent } from "../util/ClassEvent";

export class User extends ClassEvent {

    static getRef() { //ACESSAR COLEÇÃO /USERS

        //PASTA RAÍZ USERS | Todos os documentos e dados relacionados aos usuários
        return Firebase.db().collection('/users')

    }

    static findByEmail(email) {

        // @/users/doc
        return User.getRef().doc(email)

    }
}