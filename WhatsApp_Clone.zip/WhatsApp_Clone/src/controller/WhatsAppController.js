//========================================= WHATSAPP CLONE - CONTROLLER =========================================

class WhatsAppController {

    constructor() {

        this.elementsPrototype(); //Tornando a propramação mais prática
        this.loadElements(); //Carregando Elementos
        this.initEvents(); //Inicializando Eventos
    }

    //==================== INICIALIZANDO EVENTOS ====================
    initEvents() {

        // ========== ABRE O PAINEL DE EDITAR PERFIL 
        this.el.myPhoto.on('click', e => {
            this.closeAllLeftPanel();
            this.el.panelEditProfile.show();
            setTimeout(() => { this.el.panelEditProfile.addClass('open'); }, 300) // Sincronizado com o tempo de animação CSS

        })

        // ========== FECHA O PAINEL EDITAR PERFIL 
        this.el.btnClosePanelEditProfile.on('click', e => {
            this.el.panelEditProfile.removeClass('open');
        })

        // ========== ABRE O PAINEL DE ADICIONAR UM CONTATO 
        this.el.btnNewContact.on('click', e => {
            this.closeAllLeftPanel();
            this.el.panelAddContact.show();
            setTimeout(() => { this.el.panelAddContact.addClass('open'); }, 300) // Tempo de Animação do CSS

        })

        // ========== FECHA O PAINEL DE ADICIONAR UM CONTATO 
        this.el.btnClosePanelAddContact.on('click', e => {
            this.el.panelAddContact.removeClass('open');
        })

        // ========== EDITAR FOTO 
        this.el.photoContainerEditProfile.on('click', e => {
            this.el.inputProfilePhoto.click()
        })

        // ========== EDITAR NOME DE USUÁRIO
        this.el.inputNamePanelEditProfile.on('keypress', e => {
            if (e.key == "Enter") {
                e.preventDefault();
                this.el.btnSavePanelEditProfile.click();
            }
        })

        // ========== SALVA NOME DE USUÁRIO DIGITADO
        this.el.btnSavePanelEditProfile.on('click', e => {
            console.log(this.el.inputNamePanelEditProfile.innerHTML)
        })

        // ========== ENVIA EMAIL A SER ADICIONADO
        this.el.formPanelAddContact.on('submit', e => {
            e.preventDefault();
            let formData = new FormData(this.el.formPanelAddContact);
        })
    }

    //==================== FECHA TODOS OS PAINEIS À ESQUERDA ====================
    closeAllLeftPanel() {
        this.el.panelEditProfile.hide();
        this.el.panelAddContact.hide();
    }

    //==================== CARREGANDO ELEMENTOS ID to CAMELCASE ====================

    loadElements() {

        this.el = {}; //Criando um objeto
        // selecione todos os ID's, e para cada elemento ID selecionado:
        document.querySelectorAll('[id]').forEach(element => {
            //Crie um objeto, e o formate em Camel Case. Este é um elemento.
            this.el[Format.getCamelCase(element.id)] = element;

        })
    }

    //==================== PROTOTYPE | CRIANDO FUNÇÕES "NATIVAS" ====================
    elementsPrototype() {

        Element.prototype.hide = function() { //HIDE
            this.style.display = 'none';
            return this;
        }
        Element.prototype.show = function() { //SHOW
            this.style.display = 'block';
            return this;
        }
        Element.prototype.toggle = function() { //TOGGLE | Interruptor
            this.style.display = (this.style.display === 'none') ? "block" : "none";
            return this;
        }
        Element.prototype.on = function(events, fn) { //ON | addEventListener
            events.split(' ').forEach(event => {
                this.addEventListener(event, fn)
            })
            return this;
        }
        Element.prototype.css = function(styles) { //CSS | Atalho que puxa o CSS
            for (let name in styles) {
                this.style[name] = styles[name];
            }
            return this;
        }
        Element.prototype.addClass = function(name) { //ADDCLASS
            this.classList.add(name);
            return this;
        }
        Element.prototype.removeClass = function(name) { //REMOVE
            this.classList.remove(name);
            return this;
        }
        Element.prototype.toggleClass = function(name) { //TOGGLECLASS
            this.classList.toggle(name);
            return this;
        }
        Element.prototype.hasClass = function(name) { //HASCLASS
            return this.classList.contains(name);
        }
        HTMLFormElement.prototype.getForm = function() { //GETFORM | Puxa o formdata
            return new FormData(this)
        }
        HTMLFormElement.prototype.toJSON = function() { //TOJSON 
            let json = {};
            this.getForm().forEach((value, key) => {
                json[key] = value
            })
            return json;
        }
    }
}


// =========================== LÓGICA POR TRAZ DO ElementsPrototype() ===========================        
/*
~ Antes do HTML ser um HTML ele é apenas um Element

==> Element.prototype.[nome da função a ser criada] = function{
    O QUE FARÁ ESTA FUNCTION
}
*/