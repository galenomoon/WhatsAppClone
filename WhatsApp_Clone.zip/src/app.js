import { WhatsAppController } from './controller/WhatsAppController'
// importando MÓDULO(arquivo) no diretório: './controller/WhatsAppController'

window.app = new WhatsAppController();